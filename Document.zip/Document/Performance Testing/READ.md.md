Here you will find the pdf file about the Performance Testing consists of

Performance Testing