Here you will find the pdf files about the Requirement Analysis consists of



1.Solution Requirement



2.Data Flow Diagram



3.Technology Stack

