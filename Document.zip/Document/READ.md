\# Prevent-User-Deletion-if-Assigned-to-an-Incident

Here You will find all the document files related to the " Prevent user deletion if assigned to an incident" Project.



Team ID : NM2025TMID07769



Team Size : 5



Team Leader : yoga Sri



Team member : A. Anu



Team member :  K. Kaviya



Team member : D. Thirisha



Team member : S. Boomika

ServiceNow Instance: https://Developer.ServiceNow.Com



Demo Vedio Link: https://drive.google.com/file/d/1fG04zo3W-i\_qB4NgVrq3tagrR\_7dvekB/view



